﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dogShelter
{
    public class TimeSheet
    {
        /*public DateTime Date { get; }
        public static DateTime Today { get; }
        public DayOfWeek DayOfWeek { get; }*/

        private static DateTime date = DateTime.Now;
        private static int day = date.Day;

        public void FillTimeSheet()
        {
            Dog d = new Dog();
            if (day == 1 || day == 15)
            {
                List<Dog> Dogs = d.ListOfDogs();
                foreach (var dog in Dogs)
                    d.HealthCare(dog);
            }
            
        }

        public void CreatWeeklyTimeSheet()
        {
            if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                _ = new TimeSheet();
            }
        }

    }
}
