﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dogShelter
{
    public partial class TimeTable : Form
    {
        public TimeTable()
        {
            InitializeComponent();

            //dataGridView.Rows.Add("9:00", "10:00", "14:00", "18:00", "19:00");
        }

        private void calculatorButton_Click(object sender, EventArgs e)
        {
            var fr = new FoodCalculator();
            fr.ShowDialog();
        }
    }
}
