﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dogShelter
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();

            comboBoxSex.DataSource = Enum.GetValues(typeof(Dog.SexOptions));
            comboBoxSex.SelectedItem = null;
            comboBoxSize.DataSource = Enum.GetValues(typeof(Dog.SizeOptions));
            comboBoxSize.SelectedItem = null;
            comboBoxFurLength.DataSource = Enum.GetValues(typeof(Dog.FurLengthOptions));
            comboBoxFurLength.SelectedItem = null;
            comboBoxFurType.DataSource = Enum.GetValues(typeof(Dog.FurTypeOptions));
            comboBoxFurType.SelectedItem = null;
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            var dogName = nameTextBox.Text;
            var dogBreed = breedTextBox.Text;
            var dogAge = int.Parse(ageTextBox.Text);

            Dog.SexOptions dogSex = (Dog.SexOptions) comboBoxSex.SelectedItem;
            /*if (comboBoxSex.Text == "Female")
                dogSex = Dog.SexOptions.Female;
            else if (comboBoxSex.Text == "Male")
                dogSex = Dog.SexOptions.Male;
            else
                throw new Exception("Some information is missing(Unfilled box)");*/
            
            Dog.SizeOptions dogSize = (Dog.SizeOptions) comboBoxSize.SelectedItem;
            /*if(comboBoxSize.Text == "Small")
                dogSize = Dog.SizeOptions.Small;
            else if(comboBoxSize.Text == "Medium")
                dogSize = Dog.SizeOptions.Medium;
            else if(comboBoxSize.Text == "Large")
                dogSize = Dog.SizeOptions.Large;
            else if(comboBoxSize.Text == "Extra Small")
                dogSize = Dog.SizeOptions.ExtraSmall;
            else if(comboBoxSize.Text == "Extra Large")
                dogSize = Dog.SizeOptions.ExtraLarge;
            else
                throw new Exception("Some information is missing(Unfilled box)");*/

            Dog.FurLengthOptions dogFurLength = (Dog.FurLengthOptions) comboBoxFurLength.SelectedItem;
            /*if (comboBoxFurLength.Text == "Short")
                dogFurLength = Dog.FurLengthOptions.Short;
            else if (comboBoxFurLength.Text == "Long")
                dogFurLength = Dog.FurLengthOptions.Long;
            else
                throw new Exception("Some information is missing(Unfilled box)");*/

            Dog.FurTypeOptions dogFurType = (Dog.FurTypeOptions) comboBoxFurType.SelectedItem;
            /*if (comboBoxFurType.Text == "Straight")
                dogFurType = Dog.FurTypeOptions.Straight;
            else if (comboBoxFurType.Text == "Curly")
                dogFurType = Dog.FurTypeOptions.Curly;
            else
                throw new Exception("Some information is missing(Unfilled box)");*/

            switch (comboBoxBreed.SelectedIndex)
            {
                case 0:
                    new Hound()
                    {
                        Name = dogName,
                        Breed = dogBreed,
                        Age = dogAge,
                        Sex = dogSex,
                        Size = dogSize,
                        FurLength = dogFurLength,
                        FurType = dogFurType
                    };
                    break;
                case 1:
                    new Retriever()
                    {
                        Name = dogName,
                        Breed = dogBreed,
                        Age = dogAge,
                        Sex = dogSex,
                        Size = dogSize,
                        FurLength = dogFurLength,
                        FurType = dogFurType
                    };
                    break;
                case 2:
                    new Sheepdog()
                    {
                        Name = dogName,
                        Breed = dogBreed,
                        Age = dogAge,
                        Sex = dogSex,
                        Size = dogSize,
                        FurLength = dogFurLength,
                        FurType = dogFurType
                    };
                    break;
                case 3:
                    new Spitz()
                    {
                        Name = dogName,
                        Breed = dogBreed,
                        Age = dogAge,
                        Sex = dogSex,
                        Size = dogSize,
                        FurLength = dogFurLength,
                        FurType = dogFurType
                    };
                    break;
                case 4:
                    new Terrier()
                    {
                        Name = dogName,
                        Breed = dogBreed,
                        Age = dogAge,
                        Sex = dogSex,
                        Size = dogSize,
                        FurLength = dogFurLength,
                        FurType = dogFurType
                    };
                    break;
                default:
                    new Dog()
                    {
                        Name = dogName,
                        Breed = dogBreed,
                        Age = dogAge,
                        Sex = dogSex,
                        Size = dogSize,
                        FurLength = dogFurLength,
                        FurType = dogFurType
                    };
                    break;
            }
        }
    }
}
