﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dogShelter
{
    public class Dog
    {
        protected string name;
        public string Name { get { return name; } set { name = value; } }
        protected string breed;
        public string Breed { get { return breed; } set { breed = value; } }
        protected double age;
        public double Age { get { return age; } set { age = value; } }

        public Person Adopter { get; set; }

        public enum SexOptions { Female, Male};
        public enum SizeOptions { ExtraSmall, Small, Medium, Large, ExtraLarge};
        public enum FurLengthOptions { Short, Long};
        public enum FurTypeOptions { Straight, Curly};

        protected SexOptions _sex;
        public SexOptions Sex { get { return _sex; } set { _sex = value; } }

        protected SizeOptions _size;
        public SizeOptions Size { get { return _size; } set { _size = value; } }

        protected FurLengthOptions _length;
        public FurLengthOptions FurLength { get { return _length; } set { _length = value; } }

        protected FurTypeOptions _type;
        public FurTypeOptions FurType { get { return _type; } set { _type = value; } }

        private List<Dog> Dogs = new List<Dog>();
        private List<Dog> AdoptedDogs = new List<Dog>();

        public List<Dog> ListOfDogs() { return Dogs; }
        public List<Dog> ListOfAdoptedDogs() { return AdoptedDogs; }

        public void Register(string name, string breed, double age, SexOptions sex, SizeOptions size, FurLengthOptions furLength, FurTypeOptions furType)
        {
            Dog dog = new Dog
            {
                Name = name,
                Breed = breed,
                Age = age,
                Sex = sex,
                Size = size,
                FurLength = furLength,
                FurType = furType
            };
            Dogs.Add(dog);
        }
        public void Adopt(Dog dog, Person person)
        {
            Dogs.Remove(dog);
            AdoptedDogs.Add(dog);
            dog.Adopter = person;
        }
        public virtual string[] HealthCare(Dog dog)
        {
            string[] needs = new string[3] {"wash", "nail-cut", ""};
            needs[1] = dog.FurLength == 0 ? "brush" : "trim";
            return needs;
        }
        public virtual double Feed(double kg)
        {
            // (kg*10*2.5)/2, защото количеството се разделя на две порции за деня
            return kg*5*2.5;
        }

        public List<Dog> Filter(string criterion)
        {
            var resultList = new List<Dog>();

            /*for (int i = 0; i < Dogs.Count; i++)
                if (Dogs[i].Sex.Equals(criterion))
                    resultList.Add(Dogs[i]);
                else if (Dogs[i].Breed.StartsWith(criterion))
                    resultList.Add(Dogs[i]);*/

            if (criterion == "female" || criterion == "male")
            {
                for(int i = 0; i < Dogs.Count; i++)
                    if (Dogs[i].Sex.Equals(criterion))
                        resultList.Add(Dogs[i]);
            }

            for (int i = 0; i < Dogs.Count; i++)
                if (Dogs[i].Breed.StartsWith(criterion))
                    resultList.Add(Dogs[i]);

            return resultList;
        }
    }
}
